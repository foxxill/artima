from django.contrib import admin
from .models import Category, Product, Profile

class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']
    prepopulated_fields = {'slug':('name',)}
admin.site.register(Category, CategoryAdmin)

admin.site.register(Profile)

class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'price', 'description', 'created']
    list_filter = ['created']
    list_editable = ['price']
    # prepopulated_fields = {'slug': ('name',)}
admin.site.register(Product, ProductAdmin)