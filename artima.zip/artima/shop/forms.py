from django.forms import EmailField, ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Product, Profile

class ProductForm(ModelForm):
    class Meta:
        model = Product
        fields = ["image", "name", "category", "description", "price"]
        
# class RegisterForm(UserCreationForm):
#     class Meta(UserCreationForm.Meta):
#         model = User
        
class UserRegisterForm(UserCreationForm):
    email = EmailField()
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        
class ProfileRegisterForm(ModelForm):
    class Meta:
        model = Profile
        fields = ["image", "name_surname", "contacts"]