from django.db import models
from django.conf import settings
from django.contrib.auth.models import User

# создание моделей в базе данных сайта

# модель для категорий продуктов
class Category(models.Model):
    # создание поля под имя категории
    name = models.CharField(max_length = 200, db_index = True)
    # создание поля под ссылку на категорию
    slug = models.SlugField(max_length = 200, unique = True)
    image = models.ImageField(upload_to='images/category', default = 'image/default.jpg' , blank = True)
    description = models.TextField(blank = True)
    
    class Meta:
        ordering = ('name',)
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'
        
    def __str__(self):
        return self.name
    
    def categories_name(self):
        return [i.name for i in Category.objects()]
    
# модель для пользователя
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='images/profile', default='images/default.jpg')
    name_surname = models.CharField(max_length = 30, db_index = True, default='')
    contacts = models.CharField(max_length = 200, db_index = True, default='')
    
    class Meta:
        ordering = ('name_surname',)
    
    def __str__(self):
        return f'{self.user.username} Profile'
    
# модель для продуктов
class Product(models.Model):
    category = models.ForeignKey(Category, related_name = 'product', on_delete = models.CASCADE)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    # создание поля под имя продукта
    name = models.CharField(max_length = 30, db_index = True)
    # # создание поля для URL продукта
    # slug = models.SlugField(max_length = 200, db_index = True, unique = True)
    # создание поля для фото продукта
    image = models.ImageField(upload_to='images/products/%Y/%m/%d', default = 'images/default.jpg', blank = True)
    # создание поля для описания продукта
    description = models.TextField(blank = True,)
    # создание поля для указания цены
    price = models.DecimalField(max_digits = 10, decimal_places = 2)
    # создание поля с датой добавления продукта
    created = models.DateTimeField(auto_now_add = True)
    
    class Meta:
        verbose_name = 'Товар'
        verbose_name_plural = 'Товары'
        ordering = ('name',)
        # index_together = (('id', 'slug'),)
        
    def __str__(self):
        return self.name
