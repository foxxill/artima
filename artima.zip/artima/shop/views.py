from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import ProductForm, UserRegisterForm
from .models import Category, Product, Profile



def categories(request):
    categories = dict()
    for i in Category.objects.all():
        categories[i.slug] = i
    return render(request, template_name='artima/categories.html', context=categories)

def category(request, category_slug):
    category = Category.objects.get(slug=category_slug)
    products = [i for i in Product.objects.filter(category__slug=category_slug)]
    return render(request, template_name='artima/products.html', context={'category':category, 'products':products})

def search(request):
    if request.method == 'POST':
        products = []
        for i in Product.objects.all():
            if (request.POST['search'].lower() in i.name.lower()) or (request.POST['search'].lower() in i.description.lower()):
                products.append(i)
        return render(request, template_name='artima/products.html', context={'products':products})

@login_required
def add_product(request):
    if request.method == "POST":
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            product = form.save(commit=False)
            product.user = request.user
            product.save()
            return redirect('shop:profile')
    else:
        form = ProductForm()
        return render(request, template_name='artima/product_form.html', context={'form': form})
    
@login_required
def profile(request):
    prof = Profile.objects.get(user__username=request.user.username)
    products = [i for i in Product.objects.filter(user=request.user)]
    return render(request, template_name='artima/profile.html', context={'name_surname':prof.name_surname, 'image':prof.image, 'contacts':prof.contacts, 'products':products})
    
def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            prof = Profile(image = request.POST['image'], name_surname = request.POST['name_surname'], contacts = request.POST['contacts'], user = User.objects.get(username=username))
            prof.save()
        return redirect('shop:profile')
    else:
        form = UserRegisterForm()
        return render(request, 'registration/register.html', {'form': form})
    
def profile_pub(request, user):
    prof = Profile.objects.get(user__username=user)
    products = [i for i in Product.objects.filter(user__username=user)]
    return render(request, template_name='artima/profile_public.html', context={'name_surname':prof.name_surname, 'image':prof.image, 'contacts':prof.contacts, 'products':products})